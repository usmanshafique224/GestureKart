import React, { useEffect, useMemo, useRef, useState, Suspense } from 'react';
import { createRoot } from 'react-dom/client';
import { Canvas, useFrame } from '@react-three/fiber';
import { PerspectiveCamera, Text, RoundedBox, Environment } from '@react-three/drei';
import { Files, Camera, CameraOff, Play, RotateCcw, ShieldCheck, Gauge, Trophy, Activity, Hand, ArrowLeftRight, Download, Volume2, VolumeX, CircleHelp, CheckCircle2, AlertTriangle, ChevronRight } from 'lucide-react';
import { FilesetResolver, PoseLandmarker } from '@mediapipe/tasks-vision';
import { jsPDF } from 'jspdf';
import * as THREE from 'three';
import './style.css';

const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const fmt=(n)=>String(Math.max(0,Math.floor(n))).padStart(2,'0');

function Road({speed, lane}) {
  const marks=useMemo(()=>Array.from({length:18},(_,i)=>i),[]);
  const buildings=useMemo(()=>Array.from({length:26},(_,i)=>({x:i%2?5.7:-5.7,z:-i*7-4,h:2.2+((i*7)%7)*.48,w:1.1+((i*3)%4)*.22,color:['#1b3245','#203a4a','#243e4c','#172c3d'][i%4]})),[]);
  const stripes=useMemo(()=>Array.from({length:8},(_,i)=>i),[]);
  const roadRef=useRef();
  useFrame((_,dt)=>{ if(roadRef.current){ for(const mark of roadRef.current.children){ mark.position.z += dt*speed*0.28; if(mark.position.z > 2.5) mark.position.z -= 90; } } });
  return <group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.08,-30]} receiveShadow><planeGeometry args={[60,120]}/><meshStandardMaterial color="#10281f"/></mesh>
    <mesh position={[0,-.02,-35]} receiveShadow><boxGeometry args={[7,.12,100]}/><meshStandardMaterial color="#283443"/></mesh>
    <mesh position={[-3.65,.01,-35]}><boxGeometry args={[.13,.03,100]}/><meshStandardMaterial color="#f5c95c"/></mesh><mesh position={[3.65,.01,-35]}><boxGeometry args={[.13,.03,100]}/><meshStandardMaterial color="#f5c95c"/></mesh>
    <group ref={roadRef}>
      {marks.map(i=><group key={i} position={[0,0,-i*5]}>{[-1.17,1.17].map(x=><mesh key={x} position={[x,.025,-2.5]}><boxGeometry args={[.055,.025,2.2]}/><meshStandardMaterial color="#c5d0dc"/></mesh>)}</group>)}
    </group>
    {buildings.map((b,i)=><group key={i} position={[b.x,b.h/2-0.02,b.z]}><mesh castShadow><boxGeometry args={[b.w,b.h,b.w*1.5]}/><meshStandardMaterial color={b.color}/></mesh>{Array.from({length:Math.max(2,Math.floor(b.h*1.5))},(_,j)=><mesh key={j} position={[b.x<0?b.w/2+.006:-b.w/2-.006,-b.h/2+.5+j*.45,0]}><boxGeometry args={[.025,.16,.2]}/><meshStandardMaterial color="#e9bd6a" emissive="#b66b20" emissiveIntensity={.35}/></mesh>)}</group>)}
    <group position={[0,.025,-18]}>{Array.from({length:9},(_,i)=><mesh key={i} position={[-2.8+i*.7,0,0]}><boxGeometry args={[.48,.035,.8]}/><meshStandardMaterial color="#e8edf2"/></mesh>)}</group>

    <group position={[0,.025,-24]}>{stripes.map(i=><mesh key={i} position={[-2.8+i*.8,0,0]}><boxGeometry args={[.5,.025,1.1]}/><meshStandardMaterial color="#dce5ee"/></mesh>)}</group>
  </group>;
}
function Kart({lane, carZ, braking}) {
  const ref=useRef();
  useFrame((_,dt)=>{if(ref.current){ref.current.position.x=THREE.MathUtils.damp(ref.current.position.x,lane*2.05,7,dt);ref.current.rotation.z=THREE.MathUtils.damp(ref.current.rotation.z,-lane*.07,6,dt);}});
  return <group ref={ref} position={[0,0,carZ]}>
    <mesh position={[0,.43,0]} castShadow><RoundedBox args={[1.22,.48,1.75]} radius={.16} smoothness={4}><meshStandardMaterial color="#28d9b0" metalness={.28} roughness={.28}/></RoundedBox></mesh>
    <mesh position={[0,.76,-.15]} castShadow><RoundedBox args={[.86,.45,.75]} radius={.15} smoothness={4}><meshStandardMaterial color="#163c4c" metalness={.3} roughness={.2}/></RoundedBox></mesh>
    <mesh position={[0,.79,.04]}><boxGeometry args={[.62,.22,.04]}/><meshStandardMaterial color="#7ce9e1" transparent opacity={.7}/></mesh>
    {[-.52,.52].map(x=>[-.52,.52].map(z=><group key={`${x}${z}`} position={[x,.27,z]} rotation={[0,0,Math.PI/2]}><mesh castShadow><cylinderGeometry args={[.2,.2,.15,18]}/><meshStandardMaterial color="#0a111a"/></mesh><mesh position={[0,.08,0]}><cylinderGeometry args={[.09,.09,.02,16]}/><meshStandardMaterial color="#9caebb" metalness={.7}/></mesh></group>))}
    <pointLight position={[0,.6,-1.2]} color="#45f5d0" intensity={braking?0.8:.15} distance={3}/>
  </group>;
}
function TrafficCar({index,lane,carZ,speed,active,onCollision}) {
  const ref=useRef(), hitRef=useRef(false), laneRef=useRef(lane);
  const colors=['#f4b942','#4a9cff','#f05b63','#e7edf2','#a58bff'];
  const [trafficLane] = useState(()=>[-1,0,1][(index*7+1)%3]);
  useFrame((_,dt)=>{
    if(!ref.current||!active)return;
    ref.current.position.z += dt*(3.5+speed*.12);
    if(Math.abs(ref.current.position.z-carZ)<1.25 && !hitRef.current && lane===trafficLane){hitRef.current=true;onCollision();}
    if(ref.current.position.z>5){ref.current.position.z=-48-index*12;hitRef.current=false;}
  });
  return <group ref={ref} position={[trafficLane*2.05,0,-22-index*15]}>
    <mesh position={[0,.42,0]} castShadow><RoundedBox args={[1.15,.48,1.7]} radius={.13} smoothness={3}><meshStandardMaterial color={colors[index%colors.length]} metalness={.18} roughness={.38}/></RoundedBox></mesh>
    <mesh position={[0,.73,-.12]} castShadow><boxGeometry args={[.84,.38,.72]}/><meshStandardMaterial color="#1c3547" metalness={.25} roughness={.25}/></mesh>
    <mesh position={[-.36,.51,.86]}><boxGeometry args={[.2,.12,.025]}/><meshStandardMaterial color="#ff554d" emissive="#e32b2b" emissiveIntensity={.7}/></mesh>
    <mesh position={[.36,.51,.86]}><boxGeometry args={[.2,.12,.025]}/><meshStandardMaterial color="#ff554d" emissive="#e32b2b" emissiveIntensity={.7}/></mesh>
  </group>;
}
function MovingSignal({speed,active,phase,carZ,onRedViolation}) {
  const ref=useRef(), triggered=useRef(false);
  useFrame((_,dt)=>{
    if(!ref.current||!active)return;
    ref.current.position.z += dt*(2.5+speed*.09);
    if(ref.current.position.z>carZ+1.1){
      if(phase==='RED'&&speed>4&&!triggered.current)onRedViolation();
      ref.current.position.z=-58;triggered.current=false;
    }
  });
  const lamp=(y,color,on)=><mesh position={[4.18,y,.2]}><sphereGeometry args={[.13,14,14]}/><meshStandardMaterial color={color} emissive={color} emissiveIntensity={on?1.4:.05}/></mesh>;
  return <group ref={ref} position={[0,0,-28]}>
    {/* Signal pole and head are on the roadside; the zebra crossing remains across the road. */}
    <mesh position={[4.18,1.5,0]}><cylinderGeometry args={[.07,.07,3,8]}/><meshStandardMaterial color="#718291"/></mesh>
    <mesh position={[4.18,2.35,0]}><boxGeometry args={[.62,1.2,.3]}/><meshStandardMaterial color="#111b27"/></mesh>
    {lamp(2.72,'#ff4e55',phase==='RED')}{lamp(2.35,'#f6bd4a',phase==='YELLOW')}{lamp(1.98,'#31d99a',phase==='GREEN')}
    <group position={[0,.025,0]}>{Array.from({length:9},(_,i)=><mesh key={i} position={[-2.8+i*.7,0,.5]}><boxGeometry args={[.48,.035,1.2]}/><meshStandardMaterial color="#e8edf2"/></mesh>)}</group>
  </group>;
}
function Scene({lane,carZ,speed,braking,active,phase,onCollision,onRedViolation}) { return <Canvas shadows dpr={[1,1.5]} gl={{antialias:true}}><PerspectiveCamera makeDefault position={[0,4.3,7.5]} fov={57}/><fog attach="fog" args={['#0a1724',18,58]}/><ambientLight intensity={1.1}/><directionalLight position={[-5,9,5]} intensity={2.1} castShadow shadow-mapSize-width={1024} shadow-mapSize-height={1024}/><pointLight position={[0,5,-15]} color="#1ccfb1" intensity={8} distance={30}/><Suspense fallback={null}><Road speed={active?speed:0} lane={lane}/><Kart lane={lane} carZ={carZ} braking={braking}/><MovingSignal speed={speed} active={active} phase={phase} carZ={carZ} onRedViolation={onRedViolation}/>{[0,1,2,3].map(i=><TrafficCar key={i} index={i} lane={lane} carZ={carZ} speed={speed} active={active} onCollision={onCollision}/>)}</Suspense></Canvas>; }

function App(){
 const [started,setStarted]=useState(false),[lane,setLane]=useState(0),[carZ,setCarZ]=useState(.6),[speed,setSpeed]=useState(35),[score,setScore]=useState(1000),[distance,setDistance]=useState(0),[violations,setViolations]=useState(0),[cleanChanges,setCleanChanges]=useState(0),[braking,setBraking]=useState(false),[cameraOn,setCameraOn]=useState(false),[cameraError,setCameraError]=useState(''),[muted,setMuted]=useState(false),[elapsed,setElapsed]=useState(0),[lastEvent,setLastEvent]=useState('Ready to drive'),[showHelp,setShowHelp]=useState(false),[gameOver,setGameOver]=useState(false),[paused,setPaused]=useState(false),[phase,setPhase]=useState('RED');
 const videoRef=useRef(null),poseRef=useRef(null),streamRef=useRef(null),lastPoseRef=useRef(0),lastViolationRef=useRef(0),lastLaneRef=useRef(0),gameRef=useRef(false),prevFrameRef=useRef(0),audioRef=useRef(null);
 const playTone=(freq=520)=>{if(muted)return;try{const ctx=audioRef.current||(audioRef.current=new AudioContext());const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=freq;o.type='sine';g.gain.value=.045;o.connect(g);g.connect(ctx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.18);o.stop(ctx.currentTime+.2)}catch{}};
 useEffect(()=>{gameRef.current=started&&!paused&&!gameOver},[started,paused,gameOver]);
 useEffect(()=>{if(!started||paused||gameOver)return;const id=setInterval(()=>{setElapsed(v=>v+1);setDistance(v=>v+speed/3.6);},1000);return()=>clearInterval(id)},[started,paused,gameOver,speed]);
 useEffect(()=>{const cycle=()=>{const t=Math.floor(Date.now()/1000)%17;setPhase(t<8?'RED':t<10?'YELLOW':'GREEN')};cycle();const id=setInterval(cycle,250);return()=>clearInterval(id)},[]);
 useEffect(()=>{const onKey=e=>{if(e.key==='Escape'){e.preventDefault();if(started&&!gameOver)setPaused(v=>!v);return}if(paused||gameOver||!started)return;if(['ArrowLeft','a','A'].includes(e.key)){e.preventDefault();changeLane(-1)}if(['ArrowRight','d','D'].includes(e.key)){e.preventDefault();changeLane(1)}if(['ArrowUp','w','W'].includes(e.key)){e.preventDefault();moveCarDepth(-.9)}if(['ArrowDown','s','S'].includes(e.key)){e.preventDefault();moveCarDepth(.9)}if(e.key===' '){e.preventDefault();toggleBrake()}};window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey)},[started,paused,gameOver]);
 const changeLane=(dir)=>{setLane(old=>{const next=clamp(old+dir,-1,1);if(next!==old){setCleanChanges(v=>v+1);setLastEvent(dir<0?'Lane change: left':'Lane change: right');playTone(620)}return next})};
 const moveCarDepth=(delta)=>{setCarZ(z=>clamp(z+delta,-2.2,3.2));setLastEvent(delta<0?'Moving forward':'Moving backward')};
 const stopKart=()=>{setBraking(true);setSpeed(0);setLastEvent('Stopped at signal');playTone(760)};
 const toggleBrake=()=>{if(braking){setBraking(false);setSpeed(35);setLastEvent('Driving resumed');playTone(520)}else stopKart()};
 const redViolation=()=>{setViolations(v=>v+1);setLastEvent('Red light violation! -150 points');playTone(220)};
 const startCamera=async()=>{setCameraError('');try{const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:640,height:480},audio:false});streamRef.current=stream;videoRef.current.srcObject=stream;await videoRef.current.play();const vision=await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/wasm');poseRef.current=await PoseLandmarker.createFromOptions(vision,{baseOptions:{modelAssetPath:'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task',delegate:'GPU'},runningMode:'VIDEO',numPoses:1});setCameraOn(true);setLastEvent('Camera ready — lean to steer');requestAnimationFrame(trackPose)}catch(e){setCameraError('Camera could not start. Allow webcam permission and use localhost or HTTPS. Keyboard controls still work.');console.error(e)}};
 const trackPose=(now)=>{if(!poseRef.current||!videoRef.current||!streamRef.current)return; if(gameRef.current&&now-lastPoseRef.current>55&&videoRef.current.readyState>=2){lastPoseRef.current=now;try{const result=poseRef.current.detectForVideo(videoRef.current,now);const p=result.landmarks?.[0];if(p){const ls=p[11],rs=p[12],lh=p[23],rh=p[24],nose=p[0],wrist=p[16];if(ls?.visibility>.45&&rs?.visibility>.45&&lh?.visibility>.35&&rh?.visibility>.35){const torso=(ls.x+rs.x+lh.x+rh.x)/4;const diff=torso-.5;if(diff<-.09)changeLane(-1);else if(diff>.09)changeLane(1);if(wrist?.visibility>.5&&nose?.visibility>.5&&wrist.y<nose.y-.1&&now-lastViolationRef.current>1800){lastViolationRef.current=now;stopKart()}}}}catch(e){console.warn(e)}}requestAnimationFrame(trackPose)};
 const begin=()=>{setStarted(true);setPaused(false);setGameOver(false);setBraking(false);setSpeed(35);setLane(0);setCarZ(.6);setScore(1000);setDistance(0);setViolations(0);setCleanChanges(0);setElapsed(0);setLastEvent('Drive started');gameRef.current=true;playTone(480)};
 const endGame=()=>{setGameOver(true);setStarted(false);setPaused(false);gameRef.current=false;setSpeed(0);setLastEvent('GAME OVER — collision or run ended');playTone(150)};
 const report=()=>{const doc=new jsPDF();doc.setFillColor(8,17,31);doc.rect(0,0,210,297,'F');doc.setTextColor(42,220,180);doc.setFontSize(26);doc.text('GestureKart',18,24);doc.setTextColor(240,246,252);doc.setFontSize(12);doc.text('CIVIC DRIVING SCORE CARD',18,34);doc.setDrawColor(42,220,180);doc.line(18,42,192,42);doc.setFontSize(13);doc.text(`Final Civic Score: ${Math.max(0,score-violations*150)}/1000`,18,58);doc.text(`Distance driven: ${Math.round(distance)} m`,18,72);doc.text(`Session duration: ${fmt(Math.floor(elapsed/60))}:${fmt(elapsed%60)}`,18,86);doc.text(`Clean lane changes: ${cleanChanges}`,18,100);doc.text(`Traffic violations: ${violations}`,18,114);doc.setFontSize(10);doc.setTextColor(170,190,207);doc.text('Remember: stop at red lights, respect zebra crossings, and stay in lane.',18,137);doc.text('Generated by GestureKart — gesture-powered civic driving simulator.',18,150);doc.save('GestureKart-Civic-Score.pdf')};
 const scoreNow=Math.max(0,score-violations*150);
 return <div className="app"><header className="topbar"><div className="brand"><div className="brand-icon"><Activity size={22}/></div><div><strong>Gesture<span>Kart</span></strong><small>CIVIC DRIVING SIMULATOR</small></div></div><div className="top-right"><span className="live-pill"><i/> SIMULATION READY</span><button className="icon-btn" onClick={()=>setShowHelp(!showHelp)} aria-label="Help"><CircleHelp size={19}/></button><button className="icon-btn" onClick={()=>setMuted(!muted)} aria-label="Toggle sound">{muted?<VolumeX size={19}/>:<Volume2 size={19}/>}</button></div></header>
 <main><section className="intro"><div><div className="eyebrow"><span/> BUILT FOR SAFER STREETS</div><h1>Drive with your <em>gestures.</em></h1><p>A new way to learn the rules of the road. Lean to steer, raise your hand to stop, and earn your Civic Driving Score.</p></div><div className="intro-stat"><ShieldCheck size={23}/><div><b>ROAD SMART</b><span>Every move matters</span></div></div></section>
 <div className="dashboard"><section className="game-panel"><div className="game-head"><div><div className="section-kicker">LIVE SIMULATION</div><h2>Canal Road Run <span className="weather-dot"/></h2></div><div className={`status-chip ${started?'active':''}`}><span/> {gameOver?'SESSION ENDED':started?'IN PROGRESS':'STANDBY'}</div></div>
 <div className="scene-wrap"><Scene lane={lane} carZ={carZ} speed={speed} braking={braking} active={started&&!paused&&!gameOver&&!braking} phase={phase} onCollision={endGame} onRedViolation={redViolation}/><div className="scene-vignette"/><div className="hud-top"><div className="hud-box"><span>DISTANCE</span><strong>{Math.floor(distance)}<small> m</small></strong></div><div className={`signal-hud signal-${phase.toLowerCase()}`}><span className="signal-red"/><span className="signal-yellow"/><span className="signal-green"/></div><div className="hud-box right"><span>VELOCITY</span><strong>{speed}<small> km/h</small></strong></div></div><div className="lane-labels"><span>LEFT LANE</span><span>CENTER LANE</span><span>RIGHT LANE</span></div><div className="scene-bottom"><div className="event-tag"><span className="event-dot"/>{lastEvent}</div><div className="mini-score"><Trophy size={15}/><b>{scoreNow}</b><span>/1000</span></div></div>{(!started||gameOver||paused)&&<div className="start-overlay"><div className="start-emblem"><Activity size={30}/></div><h3>{gameOver?'Game over.':paused?'Game paused.': 'Ready when you are.'}</h3><p>{gameOver?'A collision ended this run. Review your scorecard or try again.':paused?'Press ESC or Resume to continue driving.':'Avoid traffic, obey red lights, and use arrow keys or gestures to drive.'}</p>{paused?<><button className="primary-btn" onClick={()=>setPaused(false)}><Play size={17} fill="currentColor"/> RESUME DRIVE <ChevronRight size={17}/></button><button className="overlay-secondary" onClick={endGame}>END GAME</button></>:<button className="primary-btn" onClick={begin}><Play size={17} fill="currentColor"/>{gameOver?'DRIVE AGAIN':'START DRIVING'}<ChevronRight size={17}/></button>}<span className="start-note">ESC TO PAUSE · ↑/↓ MOVE · SPACE BRAKE</span></div>}</div>
 <div className="game-controls"><div className="control-copy"><span className="control-icon"><Hand size={18}/></span><div><b>Gesture controls</b><small>{cameraOn?'Webcam connected':'Connect your webcam to begin'}</small></div></div><button className={`camera-btn ${cameraOn?'connected':''}`} onClick={cameraOn?()=>{streamRef.current?.getTracks().forEach(t=>t.stop());poseRef.current?.close();setCameraOn(false);setLastEvent('Camera disconnected')}:startCamera}>{cameraOn?<Camera size={16}/>:<CameraOff size={16}/>} {cameraOn?'CAMERA CONNECTED':'ENABLE CAMERA'}</button></div>
 {cameraError&&<div className="camera-error"><AlertTriangle size={16}/>{cameraError}</div>}
 <div className="keyboard-controls"><span>OR USE KEYBOARD</span><div><kbd>←</kbd><kbd>→</kbd><small>STEER</small></div><div><kbd>↑</kbd><kbd>↓</kbd><small>FORWARD / BACK</small></div><div><kbd>SPACE</kbd><small>STOP</small></div><button onClick={()=>{setLane(0);setCarZ(.6);setSpeed(35);setBraking(false)}}><RotateCcw size={13}/> RESET POSITION</button></div>
 </section>
 <aside className="side-column"><section className="metric-card score-card"><div className="card-label"><span>CIVIC DRIVING SCORE</span><Trophy size={17}/></div><div className="score-number">{scoreNow}<small>/1000</small></div><div className="score-bar"><i style={{width:`${scoreNow/10}%`}}/></div><div className="score-foot"><span>{scoreNow>=850?'EXCELLENT DRIVER':scoreNow>=650?'GOOD PROGRESS':'STAY ALERT'}</span><span>{Math.round(scoreNow/10)}%</span></div></section>
 <section className="metric-card"><div className="card-label"><span>RUN STATISTICS</span><Activity size={16}/></div><div className="stats-grid"><div className="stat"><span>TIME</span><b>{fmt(Math.floor(elapsed/60))}:{fmt(elapsed%60)}</b></div><div className="stat"><span>DISTANCE</span><b>{Math.floor(distance)}<small> m</small></b></div><div className="stat"><span>CLEAN CHANGES</span><b className="green">{cleanChanges}</b></div><div className="stat"><span>VIOLATIONS</span><b className={violations?'red':''}>{violations}</b></div></div></section>
 <section className="metric-card gesture-card"><div className="card-label"><span>HOW TO PLAY</span><span className="tiny-badge">3 GESTURES</span></div><div className="gesture-row"><div className="gesture-art lean"><ArrowLeftRight size={23}/></div><div><b>Lean left / right</b><p>Shift your torso to change lanes.</p></div><span className="gesture-key">STEER</span></div><div className="gesture-row"><div className="gesture-art stop"><Hand size={22}/></div><div><b>Raise your right hand</b><p>Lift your hand above your head to brake.</p></div><span className="gesture-key">STOP</span></div><div className="gesture-row"><div className="gesture-art speed"><Gauge size={22}/></div><div><b>Keep your posture centered</b><p>Stay balanced for a smoother run.</p></div><span className="gesture-key">FOCUS</span></div></section>
 <button className="report-btn" onClick={report}><Download size={17}/> DOWNLOAD CIVIC SCORECARD <ChevronRight size={16}/></button><button className="finish-btn" onClick={endGame} disabled={!started}><CheckCircle2 size={16}/> FINISH RUN</button>
 </aside></div>
 <footer><div>© 2026 GestureKart <span>·</span> Civic tech for safer streets</div><div><span className="footer-dot"/> CAMERA PROCESSING LOCAL TO YOUR BROWSER</div></footer>
 </main>{showHelp&&<div className="help-modal"><div className="help-box"><button className="modal-close" onClick={()=>setShowHelp(false)}>×</button><div className="section-kicker">QUICK GUIDE</div><h2>Your road. Your rules.</h2><p>Enable your webcam and allow access. Keep your upper body visible. Lean gently left or right to steer; raise your right hand above your head to stop. If camera permissions are unavailable, use Left/Right to steer, Up/Down to move forward/back, and Space to brake.</p><p><b>Scoring:</b> start with 1,000 points. Traffic violations reduce your score. Download the PDF scorecard at any time.</p><button className="primary-btn" onClick={()=>setShowHelp(false)}>GOT IT <ChevronRight size={16}/></button></div></div>}<video ref={videoRef} className="hidden-video" playsInline muted/><div className="camera-preview" style={{display:cameraOn?'block':'none'}}><video autoPlay playsInline muted ref={el=>{if(el&&videoRef.current&&el.srcObject!==videoRef.current.srcObject)el.srcObject=videoRef.current.srcObject}}/><span>CAMERA ACTIVE</span></div></div>
}

createRoot(document.getElementById('root')).render(<App/>);

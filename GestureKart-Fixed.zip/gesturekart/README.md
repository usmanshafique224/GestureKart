# GestureKart — Civic Driving Simulator

A browser-based 3D driving safety game inspired by the GestureKart hackathon brief. Drive the kart through a stylized Lahore-inspired street, steer using torso lean, raise your right hand to brake, track your civic score, and export a PDF scorecard.

## Features
- Three.js 3D road scene and animated lane markings
- Webcam pose tracking using MediaPipe Pose Landmarker
- Torso-lean lane steering and right-hand raised stop gesture
- Keyboard: ← / A and → / D to steer, ↑ / W to move forward, ↓ / S to move backward, Space to brake/resume, Esc to pause and open the end-game menu
- Run metrics, civic score UI, responsive dashboard, sound toggle
- Downloadable PDF civic scorecard

## Run locally

Requirements: Node.js 18+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. Allow camera access when prompted. Webcam access works on `localhost` and on deployed HTTPS origins. The first camera startup downloads the MediaPipe model and WASM runtime, so an internet connection is required.

## Production build

```bash
npm run build
npm run preview
```

The deployable output is generated in `dist/`.

## Deploy to Vercel
1. Push this project to a public GitHub repository.
2. Import the repository in Vercel.
3. Framework preset: **Vite**; build command: `npm run build`; output directory: `dist`.
4. Deploy and test webcam permission on the HTTPS URL.

## Controls
- Lean your torso left/right in the webcam view to steer (keep shoulders and hips visible).
- Raise your right wrist above your nose/head level to stop.
- Keyboard: ← / → or A/D to steer; ↑ / ↓ or W/S to move the car forward/backward; Space to brake/resume; Esc opens the pause menu, where you can resume or end the run.
- Select **Finish Run** to end a session; select **Download Civic Scorecard** to export a PDF.

## Suggested team split
- **CV Lead:** validate camera/model setup and tune pose thresholds.
- **Game Dev:** extend the road generator, add traffic/obstacles and collision logic.
- **UI/UX Lead:** refine sound design, score rules and scorecard styling.
- **DevOps & Submission:** deploy to Vercel, maintain GitHub README, record a two-minute demo and publish the LinkedIn announcement.

## Current prototype notes
This is a functional prototype. It includes an animated road, moving traffic vehicles, collision-triggered Game Over, roadside red/yellow/green traffic lights with a zebra crossing, red-light penalties, gesture steering/braking, forward/backward keyboard movement, keyboard controls, run metrics and a downloadable PDF scorecard. Esc opens a pause menu with Resume and End Game options. This is still a prototype: tune traffic spacing and the traffic-light timing for your target hardware, and run a production build before deployment.
